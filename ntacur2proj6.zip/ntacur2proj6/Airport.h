#include <cstdio>
#include <cstring>
#include <cstdlib>

/******************************************************************/
//Node Class
class Node
{
 private:
     int value; // for arrival airport ID
     Node* pNext;
   // Create the Data Members for the Travel Network here

 public:
     Node();
     int getAirportVal();
     void setAirportVal(int inputVal);
     Node* getNext();
     void setNext(Node* inputNext);
     bool

};

/*******************************************************************************
//List Class*/
class List
{
    private:
            Node* head;
    public:

        List();
        void addAirport(int inputVal);
        bool removeAirport(int arrival);
        void printAirport();
        void clear();
        int getListLength();
        int getNthVal(int index);

};

/************************************************************************************/
//Airport Class
 class Airport
 {
    private:
            List* adjAirport;
            bool visited;
    public:
            Airport();
            bool isVisted();
            void setVisited(bool inputVisited);
            List* getAdjAirport();

 };


 /*************************************************************************888/
 //TravelNetwork Class*/

class TravelNetwork
{
	private:
		// Create the Data Members for the Travel Network here
		Airport** airports;
		int numOfAirport;

		// To get the next input
		// Return -1 for error encountered
		int getAirportInput();
	public:
		// Use a constructor to initialize the Data Members for Travel Network
		TravelNetwork(); //default constructor

		// The main loop for reading in input

		void processCommandLoop (FILE* inFile);
		void showCommands();
		void doTravel();
		void doResize(int newSize = -1);
		void doInsert();
		void doDelete();
		void doList();
		void doFile();
		bool dfs (int a, int b);
		void depthFirstSearchHelper (int x, int y);

};
