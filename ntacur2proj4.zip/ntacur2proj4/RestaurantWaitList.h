/*  Code for the user interface for Lab 4 for CS 211 Fall 2015
 *
 *  Author: Pat Troy
 *  Date: 10/6/2013
 */
#define RestaurantWaitList.h
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef enum {FALSE = 0, TRUE, NO = 0, YES} boolean;

typedef struct list{
	char *name;
	int size1;
	int status;
	struct list *pNext;
}list;

/* interface functions */
/* forward definition of functions */
void clearToEoln();

/* Read in until the first Non-White-Space character is Read */
/* The white space characters are:
 *      space, tab \t, newline \n, vertical tab \v,
 *      form feed \f, and carriage return \r
 */
void clearToEoln();
int getNextNWSChar();
int getPosInt();
char *getName();
void printCommands();

/*linked list */
void doAdd (int ch, list **sHead,int debug);
void doCallAhead (list **sHead, int ch,int debug);
void doWaiting (list** sHead,int debug);
void doRetrieve (list** sHead, int debug);
void doList (list **sHead,int debug);
void doDisplay (list **sHead);

/* linkedListImp */
void addToList(list **sHead, char *name,int size, int ch);
boolean doesNameExist(char *name, list **sHead);
boolean  updateStatus(list** sHead, char * name, int debug);
char* retrieveAndRemove(list** sHead, int size, int debug);
int countGroupsAhead(list** sHead, char * name, int debug);
void displayGroupSizeAhead(list **sHead, char *name);
void displayListInformation(list **sHead);

