#include "RestaurantWaitList.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



boolean  updateStatus(list** sHead, char * name, int debug){
	list *temp = *sHead;
	while(temp != NULL){// strcmp compares both inputs, returns 0 if they're equal
		if(strcmp(temp->name, name) == 0){
			if(temp->status==1){//there is allready a party in line with the same name
				return FALSE;//
			}
			else{
				temp->status=1;// mark as in waiting line
				return TRUE;
			}
		}
		if(debug ==TRUE){
			printf("the size of the group is %d and the name is %s: ",temp->size1, temp->name);
 			if(temp->status==0){
 				printf(" The group is not here yet");
			 }
			if(temp->status==1){
 				printf(" The group is waiting in line");
			 }
		 printf(" \n");

		 }
		temp = temp->pNext;
	}
	return 0;// your name is not on the list default
}
void displayListInformation(list **sHead){
 	list *temp =*sHead;
 	while(temp!=NULL){
 		printf("the size of the group is %d and the name is %s: ",temp->size1, temp->name);
 		if(temp->status==0){
 			printf(" The group is not here yet");
		 }
		 if(temp->status==1){
 			printf(" The group is waiting in line");
		 }
		 printf(" \n");
		 temp = temp->pNext;
	 }
 }
void addToList(list **sHead, char *name,int size, int ch){

list *temp = (list*) malloc(sizeof(list));
 	temp->size1= size;
	temp->name = name;

	 if(ch =='a'){
	temp->status=1;//1for the're in the ewaiting line
	}
	if(ch =='c'){
	temp->status = 0;//0 for there not at the resturant
	}
	temp->pNext =NULL;

	if(*sHead ==NULL){// if head of list is empty just add the vall to it
	*sHead = temp;//return nre
	return;
	}
	else{
		list *traverse =*sHead;//go to the end of the list and add it
		while(traverse->pNext !=NULL){
			traverse = traverse->pNext;
		}
		//once at the end append traverse to the back of temp
		traverse->pNext = temp;
		return;

	}
	printf("size is:%d, name %s\n",  (*sHead)->size1, (*sHead)->name);
	return;
}

boolean doesNameExist(char *name, list **sHead){
list *temp = *sHead;
	// return flase  if theres no names in the list
	if(temp == NULL){
		return FALSE;
	}
	//loop until end of list
	while(temp != NULL){// strcmp compares both inputs, returns 0 if they're equal
		if(strcmp(temp->name, name) == 0){
			return TRUE;// there is a name in there
		}
		temp = temp->pNext;
	}
	return 0;//there is no ssae name in the list

}
char* retrieveAndRemove(list** sHead, int size, int debug){
	list *temp = *sHead;
	char *temp2;
	list  *prev;
	if(temp ==NULL){
		printf("node cannot be deleted from empty list");
		return NULL;
	}//check if the first group in list can be seated
	if(temp->size1<=size && temp->status ==1){//1 for in the returant 0 for not
		temp2 = temp->name;
		*sHead =(*sHead)->pNext;//returning
		free(temp);
		if(debug ==TRUE){
	 	displayListInformation(sHead);
	 }
		return temp2;
	}

	while(temp->pNext!= NULL){// check for anything afterwards
		if(debug ==TRUE){
			printf("the size of the group is %d and the name is %s: ",temp->size1, temp->name);
 			if(temp->status==0){
 				printf(" The group is not here yet");
			 }
			if(temp->status==1){
 				printf(" The group is waiting in line");
			 }
		 printf(" \n");

		 }
		if(temp->pNext->size1<=size&& temp->pNext->status == 1){
		//	temp2 = prev->name;
			prev= temp->pNext;
			temp2 = prev->name;
			temp->pNext = prev->pNext;
			free(prev);
			return temp2;
		}
		temp = temp->pNext;
	}

	return NULL;

}
int countGroupsAhead(list** sHead, char * name, int debug){
	list *temp =*sHead;
	int x=0;
	while(temp != NULL){

	if(strcmp(temp->name, name) == 0){//name is found
	break;
	}
	x++;
	if(debug ==TRUE){
			printf("the size of the group is %d and the name is %s: ",temp->size1, temp->name);
 			if(temp->status==0){
 				printf(" The group is not here yet");
			 }
			if(temp->status==1){
 				printf(" The group is waiting in line");
			 }
		 printf(" \n");
	 }

	temp = temp->pNext;
}
if(temp==NULL){
	printf("\nthe name is not in the waiting list");
	return 0;//return 0 to tell there was no name on list
}
printf(" there are %d groups ahead of you", x);
return 1;//there ia a name
}
//-----------------------------------------------
void displayGroupSizeAhead(list **sHead, char *name){
	list *temp =*sHead;
	while(temp != NULL){
	if(strcmp(temp->name, name) == 0){//name is found
	break;
	}
	if(temp==NULL){return;} //name is not in the waiting list
	printf("\n the size of the group  is %d ", temp->size1);

	temp = temp->pNext;
}
}
