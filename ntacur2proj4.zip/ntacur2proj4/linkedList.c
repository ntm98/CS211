#include "RestaurantWaitList.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void doAdd (int ch, list **sHead,int debug)
{

 /* get group size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Add command requires an integer value of at least 1\n");
    printf ("Add command is of form: a <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Add command requires a name to be given\n");
    printf ("Add command is of form: a <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 printf ("Adding In-restaurant group \"%s\" of size %d\n", name, size);

 // add code to perform this operation here
 	int isIT = doesNameExist(name, sHead);
 	if (isIT == 1){
 		printf("the name is allready in the list");
 		return;
	 }
    addToList(sHead, name, size, ch );
     if(debug ==TRUE){
	 	printf("Currently in waiting list\n");
	 	displayListInformation(sHead);
	 }
}
//--------------------------------------------------------------------------
void doCallAhead (list **sHead, int ch,int debug)
{
 /* get group size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Call-ahead command requires an integer value of at least 1\n");
    printf ("Call-ahead command is of form: c <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Call-ahead command requires a name to be given\n");
    printf ("Call-ahead command is of form: c <size> <name>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    printf ("         <name> is the name of the group making the reservation\n");
    return;
   }

 printf ("Adding Call-ahead group \"%s\" of size %d\n", name, size);

 // add code to perform this operation here

 	int isIT = doesNameExist(name, sHead);
 	if (isIT == 1){
 		printf("the name is allready in the list");
 		return;
	 }

    addToList(sHead, name, size, ch );

  if(debug ==TRUE){
	 	printf("Currently in waiting list\n");
	 	displayListInformation(sHead);
	 }

}

void doWaiting (list** sHead,int debug)
{
 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: Waiting command requires a name to be given\n");
    printf ("Waiting command is of form: w <name>\n");
    printf ("  where: <name> is the name of the group that is now waiting\n");
    return;
   }


 // add code to perform this operation here
 boolean isIT = doesNameExist(name,sHead);
 if(isIT==FALSE){
 	printf("the party name does not exist");
 	return;
 }
 boolean status = updateStatus(sHead,name,debug);
 if(status ==FALSE){
 	printf("Your name is not a call head group");
 }
 else{
  printf ("Call-ahead group \"%s\" is now waiting in the restaurant\n", name);
}

}


void doRetrieve (list** sHead, int debug)
{
 /* get table size from input */
 int size = getPosInt();
 if (size < 1)
   {
    printf ("Error: Retrieve command requires an integer value of at least 1\n");
    printf ("Retrieve command is of form: r <size>\n");
    printf ("  where: <size> is the size of the group making the reservation\n");
    return;
   }
 clearToEoln();
 printf ("Retrieve (and remove) the first group that can fit at a tabel of size %d\n", size);
 // add code to perform this operation here
 char *x = retrieveAndRemove (sHead, size,debug );
 if(x!=NULL){// we removed a name

 	printf("name removed from waiting list %s", x);
  }
  else{
  	printf("the curent party froup is not in the returant");// there is only one waiting group and they are not in the resturant
  }

}

void doList (list **sHead,int debug)
{
 /* get group name from input */
 char *name = getName();
 if (NULL == name)
   {
    printf ("Error: List command requires a name to be given\n");
    printf ("List command is of form: l <name>\n");
    printf ("  where: <name> is the name of the group to inquire about\n");
    return;
   }

 printf ("Group \"%s\" is behind the following groups\n", name);

 // add code to perform this operation here
 int x =countGroupsAhead (sHead, name,debug);
 if(x==0){;}//if 0 there is no name, error measage will be displayed
 else{
 displayGroupSizeAhead(sHead,name);
}
}

void doDisplay (list **sHead)
{
 clearToEoln();
 printf ("Display information about all groups\n");
 displayListInformation (sHead);
 }
