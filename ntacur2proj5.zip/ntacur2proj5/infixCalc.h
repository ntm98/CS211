#ifndef HEADER_H
#define HEADER_H


#include <cstdio>
#include <cstring>
#include <cctype>


#define TRUE 1
#define FALSE 0


class ValStack{
	private:
	int *numbers;
	int top;
	int size;
	public:
	void initValStack();
	bool StackValEmpty();
	int getVal();
	void push( int val);
	void reset(ValStack *ptrOp);
	void pop();
	void reset();
	int returnValTop();
};

class OpStack{
	private:
		char *op1;
		int top;
		int size;
	public:
	void initOpStack();	
	void push(char op);
	bool StackOpEmpty();
	void reset(OpStack *ptrOp);
	char returnOpTop();//return the top value in the stack
	void pop();


};

#endif


