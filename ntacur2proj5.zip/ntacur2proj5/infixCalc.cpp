#include "infixCalc.h"

char OpStack::returnOpTop(){// returns top operator if stack is not empty
	if(this->op1==NULL){
		printf("\n there are no operators on the stack");
		return '0';
	}
	else{
	return this->op1[this->top];
}
}
//----------------------------------------------
bool OpStack::StackOpEmpty(){//shows if operator is empty
	if(this->top==-1){
		return true; //stack has no members
	}
	else{
		return false;//stack has members
	}
}
void OpStack::push( char sign){
	  /* check if enough space currently on stack and grow if needed */
	if((this->top) >= (this->size)-1){
		char *temp = new char[this->size+2];
		int i;
		for(i =0; i<this->size;i++){
			temp[i] =this->op1[i];
		}
		delete(this->op1);
		this->op1 = temp;
		this->size = this->size+2;
	}
  /* add val onto stack */
	this->top = this->top + 1; //incement top

    this->op1[this->top] = sign;//push in operator
	}
	//---------------------------------------------------

void OpStack::initOpStack(){//initialize Operator Stack
	this->size = 2;
	this->op1= new	char[this->size];
	this->top = -1;
}
void OpStack::pop(){// if stack is not empty popoperator
	if(this->top == -1){
	;//do nothing
	}
  else{
    this->top= this->top-1;
    this->size--;
  }
}
//----------------------------------
void OpStack::reset(OpStack *ptrOp){// reset to reuse
delete this->op1;
ptrOp->initOpStack();

}
void ValStack::initValStack(){
this->size = 2;
this->numbers = new	int[this->size];
this->top = -1;
}
int ValStack::getVal(){
	return this->numbers[this->top];
}
//------------------------------------------
int ValStack::returnValTop(){//returns top val
	if(this->top==-1){
		printf("\n there is no Value on the Top Value stack");
		return -999;
	}
	else{
	return this->numbers[this->top];
}
}
//--------------------------------------------------------
bool ValStack::StackValEmpty(){//checks for empty satck
	if(this->top==-1){
		return true; //stack has no members
	}
	else{
		return false;//stack has members
	}
}
//-----------------------------------------------------------------------
	void ValStack::push( int val){
	  /* check if enough space currently on stack and grow if needed */
	if((this->top) >= (this->size)-1){
		int *temp = new int[this->size+2];
		int i;
		for(i =0; i<this->size;i++){
			temp[i] =this->numbers[i];
		}
		delete(this->numbers);
		this->numbers = temp;
		this->size = this->size+2;
	}
  /* add val onto stack */
	this->top = this->top + 1; //incement top

    this->numbers[this->top] = val;
	}
	void ValStack::pop(){
	if(this->top == -1){//if theres no value do nothing
	;//do nothing
	}
  else{
    this->top= this->top-1;
    this->size--;
  }

}
//-----------------------------------------------------------------
void ValStack::reset(ValStack *ptrVal){//resets function
	delete this->numbers;
	ptrVal->initValStack();

}

